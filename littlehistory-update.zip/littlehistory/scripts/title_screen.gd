extends Control

const HOME_BG = preload("res://assets/generated/cozy_home.png")
const BOY_TEX = preload("res://assets/generated/male_hero.png")
const GIRL_TEX = preload("res://assets/generated/female_hero.png")
const CYRILLIC_FONT = preload("res://assets/fonts/cyrillic_regular.tres")

var saved_level := 0
var title_label: Label
var subtitle_label: Label
var content: VBoxContainer
var dialog: PanelContainer
var pulse := 0.0
var mobile_layout := false

func _ready() -> void:
	saved_level = _saved_level()
	set_process(true)
	_build_ui()
	queue_redraw()

func _saved_level() -> int:
	var cfg := ConfigFile.new()
	if cfg.load("user://littlehistory.cfg") == OK:
		return clampi(int(cfg.get_value("progress", "unlocked_level", 0)), 0, 3)
	return 0

func _process(delta: float) -> void:
	pulse += delta
	queue_redraw()

func _draw() -> void:
	var size := get_viewport_rect().size
	draw_texture_rect(HOME_BG, Rect2(Vector2.ZERO, size), false)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.08, 0.06, 0.12, 0.22), true)
	draw_circle(Vector2(size.x * 0.83, size.y * 0.16), 120.0 + sin(pulse) * 4.0, Color(1.0, 0.78, 0.54, 0.12))
	for i in 12:
		var x := 40.0 + float(i) * 122.0
		var y := 100.0 + fmod(float(i * 47), maxf(1.0, size.y - 180.0))
		draw_circle(Vector2(x, y), 2.5, Color(1, 0.9, 0.72, 0.34))

func _build_ui() -> void:
	mobile_layout = get_viewport_rect().size.x < 900.0
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 16 if mobile_layout else 46)
	margin.add_theme_constant_override("margin_right", 16 if mobile_layout else 46)
	margin.add_theme_constant_override("margin_top", 18 if mobile_layout else 34)
	margin.add_theme_constant_override("margin_bottom", 18 if mobile_layout else 34)
	add_child(margin)
	var layout: BoxContainer = VBoxContainer.new() if mobile_layout else HBoxContainer.new()
	layout.add_theme_constant_override("separation", 12 if mobile_layout else 28)
	margin.add_child(layout)
	var left_card := PanelContainer.new()
	left_card.custom_minimum_size = Vector2(0, 300 if mobile_layout else 0)
	left_card.add_theme_stylebox_override("panel", _style(Color(0.12,0.08,0.16,0.92), Color("#f2c5a3"), 3, 28))
	layout.add_child(left_card)
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 10)
	left_card.add_child(left)
	var eyebrow := _label("АВТОРСКОЕ РОМАНТИЧЕСКОЕ ПРИКЛЮЧЕНИЕ", 14, Color("#f6c1a4"))
	eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	left.add_child(eyebrow)
	title_label = _label("Наша маленькая\nистория", 34 if mobile_layout else 47, Color("#fff0cf"))
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.add_theme_color_override("font_outline_color", Color("#4b304a"))
	title_label.add_theme_constant_override("outline_size", 8)
	left.add_child(title_label)
	subtitle_label = _label("Два героя. Четыре места.\nОдна маленькая история, которую вы создаёте вместе.", 15 if mobile_layout else 18, Color("#f7dbc2"))
	subtitle_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	left.add_child(subtitle_label)
	var divider := HSeparator.new()
	left.add_child(divider)
	var play := _button("ИГРАТЬ", Vector2(0, 48 if mobile_layout else 58), true)
	play.pressed.connect(func(): _start_game(0))
	left.add_child(play)
	var continue_button := _button("ПРОДОЛЖИТЬ  ·  УРОВЕНЬ %d" % (saved_level + 1), Vector2(0, 44 if mobile_layout else 52), false)
	continue_button.pressed.connect(func(): _start_game(saved_level))
	left.add_child(continue_button)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	left.add_child(row)
	var settings := _button("Настройки", Vector2(0, 42 if mobile_layout else 46), false)
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(_show_settings)
	row.add_child(settings)
	var about := _button("Об игре", Vector2(0, 42 if mobile_layout else 46), false)
	about.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	about.pressed.connect(_show_about)
	row.add_child(about)
	var controls := _label("Управляйте героями большими экранными кнопками\nСобирайте сердечки и решайте задачи вдвоём.", 13 if mobile_layout else 14, Color("#d8b7ba"))
	controls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	left.add_child(controls)
	var footer := _label("Прогресс сохраняется автоматически  ·  офлайн", 12 if mobile_layout else 13, Color("#b692a1"))
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	left.add_child(footer)
	var gallery_card := PanelContainer.new()
	if mobile_layout:
		gallery_card.custom_minimum_size = Vector2(0, 290)
	gallery_card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gallery_card.add_theme_stylebox_override("panel", _style(Color(0.15,0.10,0.18,0.84), Color("#dca6a1"), 2, 28))
	layout.add_child(gallery_card)
	var gallery := VBoxContainer.new()
	gallery.add_theme_constant_override("separation", 8)
	gallery_card.add_child(gallery)
	var gallery_title := _label("ГАЛЕРЕЯ ГЕРОЕВ", 15 if mobile_layout else 17, Color("#f8cfaf"))
	gallery_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	gallery.add_child(gallery_title)
	var portraits := HBoxContainer.new()
	portraits.alignment = BoxContainer.ALIGNMENT_CENTER
	portraits.add_theme_constant_override("separation", 12)
	portraits.size_flags_vertical = Control.SIZE_EXPAND_FILL
	gallery.add_child(portraits)
	_add_portrait(portraits, BOY_TEX, "Парень\nспокойный и с юмором")
	_add_portrait(portraits, GIRL_TEX, "Девушка\nозорная и смелая")
	var note := _label("Два героя — одна история.\nМеняйте героя кнопкой ⇄.", 13 if mobile_layout else 17, Color("#efd0bf"))
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	gallery.add_child(note)

func _add_portrait(parent: Container, texture: Texture2D, caption: String) -> void:
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var frame := PanelContainer.new()
	frame.custom_minimum_size = Vector2(135, 205) if mobile_layout else Vector2(170, 330)
	frame.add_theme_stylebox_override("panel", _style(Color(0.34,0.18,0.28,0.55), Color("#f0c09f"), 2, 22))
	box.add_child(frame)
	var image := TextureRect.new()
	image.texture = texture
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image.custom_minimum_size = Vector2(125, 180) if mobile_layout else Vector2(160, 300)
	frame.add_child(image)
	var text := _label(caption, 13 if mobile_layout else 15, Color("#fff0d0"))
	text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(text)
	parent.add_child(box)

func _label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_override("font", CYRILLIC_FONT)
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0.18,0.10,0.18,0.6))
	label.add_theme_constant_override("outline_size", 3)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return label

func _style(fill: Color, border: Color, width: int, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(width)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 14
	style.content_margin_bottom = 14
	return style

func _button(text: String, size: Vector2, primary: bool) -> Button:
	var button := Button.new()
	button.text = text
	button.add_theme_font_override("font", CYRILLIC_FONT)
	button.custom_minimum_size = size
	button.add_theme_font_size_override("font_size", 20 if primary else 16)
	button.add_theme_color_override("font_color", Color("#fff0d0"))
	button.add_theme_stylebox_override("normal", _style(Color("#6c465e") if primary else Color(0.23,0.15,0.25,0.88), Color("#edb79e"), 2, 16))
	button.add_theme_stylebox_override("hover", _style(Color("#a45f75"), Color("#ffe0bd"), 3, 16))
	button.add_theme_stylebox_override("pressed", _style(Color("#4d385d"), Color("#f5c398"), 3, 16))
	return button

func _start_game(start_level: int) -> void:
	get_tree().set_meta("littlehistory_start_level", clampi(start_level, 0, 3))
	get_tree().change_scene_to_file("res://scenes/game.tscn")

func _show_settings() -> void:
	_show_dialog("Настройки", "Звук и музыка\nВ этой офлайн-версии звук не используется, поэтому игра тихая и не отвлекает.\n\nПодсказки управления всегда доступны внизу экрана.")

func _show_about() -> void:
	_show_dialog("Об игре", "«Наша маленькая история» — маленькое приключение о том, как вдвоём проще находить путь.\n\nСобирайте сердечки, ищите памятные предметы, активируйте механизмы и не забывайте переключаться между героями.\n\nВизуальный стиль создан с нуля по мотивам предоставленного стилевого референса; персонажи оригинальные.")

func _show_dialog(title_text: String, body_text: String) -> void:
	if dialog != null: dialog.queue_free()
	dialog = PanelContainer.new()
	dialog.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	dialog.position -= Vector2(300, 190)
	dialog.size = Vector2(600, 380)
	dialog.add_theme_stylebox_override("panel", _style(Color(0.10,0.07,0.15,0.98), Color("#efb69e"), 3, 26))
	add_child(dialog)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	dialog.add_child(box)
	var title := _label(title_text, 28, Color("#fff0d0"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	var body := _label(body_text, 18, Color("#f0d1c4"))
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(body)
	var close := _button("Закрыть", Vector2(0, 52), false)
	close.pressed.connect(func(): dialog.queue_free(); dialog = null)
	box.add_child(close)
